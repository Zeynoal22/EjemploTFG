package com.example.buscaminas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.graphics.drawable.Icon;
import android.media.Image;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import androidx.gridlayout.widget.GridLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Random;

public class Main extends AppCompatActivity {
    TextView tv1;
    TextView tv2;
    static int dificultad=1;
    static int personaje;
    private MenuItem menuItem;

    private Button [][] campo;
    private GridLayout gridLayout;

    private boolean primerClic = true;

   int[] personajes= new int []{
           R.drawable.icono1,
           R.drawable.icono2,
           R.drawable.icono3,
           R.drawable.icono4
   };
   int redFlag = R.drawable.redflag;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridLayout=findViewById(R.id.gridLayout);
        crearCampoMinado(dificultad);

    }

    public void crearCampoMinado(int dificultad){
        int minas=0;
        int casillas =0;
        if(dificultad == 1){
            casillas = 8;
            minas=10;
        }else if (dificultad==2){
            casillas = 12;
            minas=30;
        }else if (dificultad==3){
            casillas = 16;
            minas=60;
        }
        gridLayout.setColumnCount(casillas);
        gridLayout.setRowCount(casillas);

        int a = getResources().getDisplayMetrics().widthPixels;
        int b = getResources().getDisplayMetrics().heightPixels;

        int tamanyo = Math.min(a/casillas, b/casillas);

        campo = new Button[casillas][casillas];
        for (int fila = 0; fila < campo.length; fila++) {
            for (int columna = 0; columna < campo.length; columna++) {
                campo[fila][columna] = new Button(this);
                campo [fila][columna].setPadding(0,0,0,0);
                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = tamanyo;
                params.height = tamanyo;
                campo[fila][columna].setLayoutParams(params);

                int finalMinas = minas;
                int finalFila = fila;
                int finalColumna = columna;
                campo[fila][columna].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                       if(primerClic){
                           colocarMinas(finalMinas, finalFila, finalColumna);
                           primerClic=false;
                       } if (campo[finalFila][finalColumna].getTag() != null && campo[finalFila][finalColumna].getTag().equals("mina")) {
                            // esto pone la imagen de la mina cuando clikas encimas espero acordarme de descomentarlo luego
                          campo[finalFila][finalColumna].setBackgroundResource(personajes[personaje]);
                            perder();
                           // gridLayout.removeAllViews();

                        }  else {
                            descubrirCasillas(finalFila, finalColumna);
                        }
                    }
                });
                campo[finalFila][finalColumna].setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        if (campo[finalFila][finalColumna].getTag() == null) {
                            // No hay etiqueta, establecer la bandera
                            campo[finalFila][finalColumna].setBackgroundResource(redFlag);
                            if (campo[finalFila][finalColumna].getTag() != null && campo[finalFila][finalColumna].getTag().equals("mina")) {
                                campo[finalFila][finalColumna].setTag("minaMarcada");
                            } else {
                                campo[finalFila][finalColumna].setTag("marcada");
                            }
                        } else {
                            // Verificar si es una bandera y quitarla
                            campo[finalFila][finalColumna].setBackground(null);
                            if (campo[finalFila][finalColumna].getTag() != null && campo[finalFila][finalColumna].getTag().equals("minaMarcada")) {
                                campo[finalFila][finalColumna].setTag("mina");
                            } else {
                                campo[finalFila][finalColumna].setTag(null);
                            }
                        }
                        return true;
                    }
                });
                gridLayout.addView(campo[fila][columna]);
            }
        }

    }
    public void colocarMinas(int cantidadMinas, int filaInicial, int columnaInicial) {
        Random random = new Random();
        int filas = campo.length;
        int columnas = campo[0].length;

        for (int i = 0; i < cantidadMinas; i++) {
            int fila, columna;
            do {

                fila = random.nextInt(filas);
                columna = random.nextInt(columnas);
            } while (campo[fila][columna].getTag() != null || (fila == filaInicial && columna == columnaInicial)); // Verifica si ya hay una mina en esta casilla o es la casilla inicial


            campo[fila][columna].setTag("mina");
            // ayuda visual para ver las minas espero acordarme de comentarlo luego
        //  campo[fila][columna].setBackgroundResource(personajes[personaje]);

        }
    }

    public  void perder(){
        String  texto = "Has perdido";
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setMessage(texto);
        alertBuilder.setPositiveButton("Aceptar", null);
        alertBuilder.setNegativeButton("Nueva partida", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                gridLayout.removeAllViews();
                crearCampoMinado(dificultad);
                primerClic=true;
            }
        });
        AlertDialog dialog = alertBuilder.create();
        dialog.show();
    }

    public int contarMinasAdyacentes(int fila, int columna) {
        int contadorMinas = 0;
        int filas = campo.length;
        int columnas = campo[0].length;

        // Coordenadas relativas de las 8 casillas adyacentes
        int[][] adyacentes = {
                {-1, -1}, {-1, 0}, {-1, 1},
                {0, -1},           {0, 1},
                {1, -1}, {1, 0}, {1, 1}
        };

        for (int[] offset : adyacentes) {
            int nuevaFila = fila + offset[0];
            int nuevaColumna = columna + offset[1];

            // Verifica si la nueva posición está dentro de los límites del campo
            if (nuevaFila >= 0 && nuevaFila < filas && nuevaColumna >= 0 && nuevaColumna < columnas) {
                // Verifica si hay una mina en la casilla adyacente
                if (campo[nuevaFila][nuevaColumna].getTag() != null && campo[nuevaFila][nuevaColumna].getTag().equals("mina")) {
                    contadorMinas++;
                }
            }
        }

        return contadorMinas;
    }
    private void descubrirCasillas(int fila, int columna) {
        if (campo[fila][columna].getTag() == null) {
            // No se ha descubierto esta casilla
            campo[fila][columna].setText(String.valueOf(contarMinasAdyacentes(fila, columna)));
           if( contarMinasAdyacentes( fila,columna)==0){
               campo[fila][columna].setText("");
               campo[fila][columna].setBackgroundResource(R.drawable.cruz);
           }
            campo[fila][columna].setTag("descubierta");

            if (contarMinasAdyacentes(fila, columna) == 0) {
                // La casilla está vacía, descubrir casillas adyacentes
                descubrirCasillasAdyacentes(fila, columna);
            }
        }
    }
    private void descubrirCasillasAdyacentes(int fila, int columna) {
        int filas = campo.length;
        int columnas = campo[0].length;

        // Coordenadas relativas de las 8 casillas adyacentes
        int[][] adyacentes = {
                {-1, -1}, {-1, 0}, {-1, 1},
                {0, -1},           {0, 1},
                {1, -1}, {1, 0}, {1, 1}
        };

        for (int[] offset : adyacentes) {
            int nuevaFila = fila + offset[0];
            int nuevaColumna = columna + offset[1];

            // Verifica si la nueva posición está dentro de los límites del campo
            if (nuevaFila >= 0 && nuevaFila < filas && nuevaColumna >= 0 && nuevaColumna < columnas) {
                descubrirCasillas(nuevaFila, nuevaColumna);
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu1, menu);
        menuItem = menu.findItem(R.id.icono);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem menuItem) {
        String texto = "";
        final String[] dificultades = {""};
        if (menuItem.getItemId() == R.id.Instrucciones) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            texto = "El Buscaminas es un juego de lógica en el que el objetivo es descubrir todas las casillas vacías en un tablero sin detonar ninguna mina. Aquí tienes las reglas clave:\n" +
                    "\n" +
                    "Haz clic en una casilla para descubrirla.\n" +
                    "Los números en las casillas reveladas indican cuántas minas hay en casillas adyacentes.\n" +
                    "Usa la información de los números para evitar las minas.\n" +
                    "Si seleccionas una mina, pierdes automáticamente.\n" +
                    "Marca casillas sospechosas de contener minas con banderas.\n" +
                    "Gana al descubrir todas las casillas seguras.\n" +
                    "¡Demuestra tu habilidad y lógica para ganar en el Buscaminas!";
            builder.setMessage(texto);
            builder.setPositiveButton("Aceptar", null);
            AlertDialog dialog = builder.create();
            dialog.show();


        } else if (menuItem.getItemId() == R.id.NuevoJuego) {

            gridLayout.removeAllViews();
            crearCampoMinado(dificultad);
            primerClic=true;

        } else if (menuItem.getItemId() == R.id.Dificultad) {
            View customView = getLayoutInflater().inflate(R.layout.dificultades, null);
            RadioButton radioOption1 = customView.findViewById(R.id.radioOption1);
            RadioButton radioOption2 = customView.findViewById(R.id.radioOption2);
            RadioButton radioOption3 = customView.findViewById(R.id.radioOption3);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(customView);
            builder.setTitle("Selecciona una opción:");
            builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (radioOption1.isChecked()) {
                        dificultades[0] = "Principiante";
                        dificultad = 1;
                    } else if (radioOption2.isChecked()) {
                        dificultades[0] = "Amateur";
                        dificultad = 2;
                    } else if (radioOption3.isChecked()) {
                        dificultades[0] = "Avanzado";
                        dificultad = 3;
                    }
                    dialog.dismiss();
                }
            });
            builder.create().show();
        } else if (menuItem.getItemId() == R.id.CambiarPersonaje) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            View dialogView = getLayoutInflater().inflate(R.layout.personaje, null);
            final Spinner mySpinner = dialogView.findViewById(R.id.my_spinner);
            final ArrayList<String> personajes = new ArrayList<>();
            personajes.add("Personaje 1");
            personajes.add("Personaje 2");
            personajes.add("Personaje 3");
            personajes.add("Personaje 4");
            int[] iconos = {R.drawable.icono1, R.drawable.icono2, R.drawable.icono3, R.drawable.icono4};
            final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, personajes);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mySpinner.setAdapter(adapter);
            builder.setView(dialogView);
            builder.setTitle("Selecciona un personaje:");
            builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    personaje = mySpinner.getSelectedItemPosition();
                    menuItem.setIcon(iconos[personaje]);
                    dialog.dismiss();
                }
            });
            builder.create().show();
        }
        return true;
    }

}
