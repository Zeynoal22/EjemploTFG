package com.example.buscaminas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class Main extends AppCompatActivity {

    TextView tv1;
    TextView tv2;
    static int dificultad;
    static int personaje;
    private MenuItem menuItem;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1= findViewById(R.id.textView2);
        tv2= findViewById(R.id.textView2);


    }
    public boolean onCreateOptionsMenu(Menu menu){
    getMenuInflater().inflate(R.menu.menu1, menu);
    menuItem=findViewById(R.id.icono);
    return true;
    }
    public boolean onOptionsItemSelected(MenuItem menuItem){
        getSupportActionBar().setIcon(R.drawable.icono2);

    String texto="";
        final String[] dificultades = {""};
    if(menuItem.getItemId() == R.id.Instrucciones){
        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        texto="El Buscaminas es un juego de lógica en el que el objetivo es descubrir todas las casillas vacías en un tablero sin detonar ninguna mina. Aquí tienes las reglas clave:\n" +
                "\n" +
                "Haz clic en una casilla para descubrirla.\n" +
                "Los números en las casillas reveladas indican cuántas minas hay en casillas adyacentes.\n" +
                "Usa la información de los números para evitar las minas.\n" +
                "Si seleccionas una mina, pierdes automáticamente.\n" +
                "Marca casillas sospechosas de contener minas con banderas.\n" +
                "Gana al descubrir todas las casillas seguras.\n" +
                "¡Demuestra tu habilidad y lógica para ganar en el Buscaminas!";
        builder.setMessage(texto);
        builder.setPositiveButton("Aceptar", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }else if(menuItem.getItemId()==R.id.NuevoJuego){
        
    } else if (menuItem.getItemId()==R.id.Dificultad) {

        View customView = getLayoutInflater().inflate(R.layout.dificultades, null);
        RadioButton radioOption1 = customView.findViewById(R.id.radioOption1);
        RadioButton radioOption2 = customView.findViewById(R.id.radioOption2);
        RadioButton radioOption3 = customView.findViewById(R.id.radioOption3);

        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setView(customView);
        builder.setTitle("Selecciona una opción:");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (radioOption1.isChecked()) {
                    dificultades[0] = "Principiante";
                    dificultad=1;
                } else if (radioOption2.isChecked()) {
                    dificultades[0] = "Amateur";
                    dificultad=2;
                } else if (radioOption3.isChecked()) {
                    dificultades[0] = "Avanzado";
                    dificultad=3;
                }

                dialog.dismiss();
            }
        });

        builder.create().show();



    }else if (menuItem.getItemId() == R.id.CambiarPersonaje) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.personaje, null);
        final Spinner mySpinner = dialogView.findViewById(R.id.my_spinner);

        // Crear una lista de nombres de personajes
        final ArrayList<String> personajes = new ArrayList<>();
        personajes.add("Personaje 1");
        personajes.add("Personaje 2");
        personajes.add("Personaje 3");
        int [] iconos={R.drawable.icono1,R.drawable.icono2, R.drawable.icono3, R.drawable.icono4};

        // Crear un adaptador personalizado para el Spinner
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, personajes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Establecer el adaptador en el Spinner
        mySpinner.setAdapter(adapter);

        builder.setView(dialogView);
        builder.setTitle("Selecciona un personaje:");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
              int selectedPersonajeIndex = mySpinner.getSelectedItemPosition();

              menuItem.setIcon(iconos[selectedPersonajeIndex]);
                tv2.setText(menuItem.getIcon().toString());

                dialog.dismiss();
            }
        });

        builder.create().show();
    }


        return true;
    }
}